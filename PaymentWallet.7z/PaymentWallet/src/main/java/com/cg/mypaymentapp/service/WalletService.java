package com.cg.mypaymentapp.service;

import java.math.BigDecimal;
import java.util.List;

import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.exception.InsufficientBalanceExceptionImpl;
import com.cg.mypaymentapp.exception.InvalidInputExceptionImpl;

public interface WalletService {
	public void createAccount(Customer customer);
	public Customer showBalance (String mobileno);
	public Customer fundTransfer (String sourceMobileNo,String targetMobileNo, BigDecimal amount);
	public Customer depositAmount (String mobileNo,BigDecimal amount );
	public Customer withdrawAmount(String mobileNo, BigDecimal amount);
	public boolean inputValidation(String name,String mobile)throws InvalidInputExceptionImpl;
	public boolean balanceValidation(BigDecimal amount,String mobNo) throws InsufficientBalanceExceptionImpl;
	public boolean mobileValidation(String mobile)throws InvalidInputExceptionImpl;
	public boolean transferValidation(BigDecimal amount,String mobNoS) throws InsufficientBalanceExceptionImpl;
	public boolean checkMobile(String mobileNo);
	public List<String> printTransactions();
	
}
