package com.cg.mypaymentapp.exception;

public class InvalidInputExceptionImpl extends RuntimeException {
	
	public InvalidInputExceptionImpl(String msg) {
		super(msg);
	}
}
