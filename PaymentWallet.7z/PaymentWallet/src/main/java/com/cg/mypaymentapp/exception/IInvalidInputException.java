package com.cg.mypaymentapp.exception;

public interface IInvalidInputException {

	String ERROR1 = "Invalid Mobile Number";
	String ERROR2 = "Invalid Name";
	String ERROR3 = "Customer alreay exist";
}
