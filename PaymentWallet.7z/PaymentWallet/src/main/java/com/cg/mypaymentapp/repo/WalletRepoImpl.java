package com.cg.mypaymentapp.repo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import com.cg.mypaymentapp.beans.Customer;

public class WalletRepoImpl implements WalletRepo {
	
	private static Map<String, Customer> data;
	private static List<String> transactions;
	static {
		data = new HashMap<String, Customer>();
		transactions = new ArrayList<String>();
	}


	public String save(Customer customer) {
		// TODO Auto-generated method stub
		data.put(customer.getMobileNo(), customer);
		
		return customer.getMobileNo();
	}

	public Customer findOne(String mobileNo) {
		Customer custSearch=null;
		if(data.containsKey(mobileNo)) {
			custSearch=data.get(mobileNo);
		}
		
		else {
			custSearch=null;
		}
		return custSearch;
		// TODO Auto-generated method stub
		}
	
	public boolean checkMobile(String mobileNo) {
	boolean check=false;
		if(data.containsKey(mobileNo))
			check=true;
		else {
			check=false;
		}
		return check;
		
	}
	
	public void addTransactions(String transaction) {
		// TODO Auto-generated method stub
		transactions.add(transaction);
		
	}

	
	public List<String> printTransactions() {
		return transactions;
		// TODO Auto-generated method stub
		
	}
	


}
