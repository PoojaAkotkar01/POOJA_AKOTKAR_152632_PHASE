package com.cg.mypaymentapp.exception;

public class InsufficientBalanceExceptionImpl extends RuntimeException {
	public InsufficientBalanceExceptionImpl(String msg) {
		super(msg);
	}
}
